# @vue/shared

Internal utility functions and constants shared across `@vue` packages.
