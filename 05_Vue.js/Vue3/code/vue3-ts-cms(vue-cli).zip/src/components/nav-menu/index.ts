import navMenu from './src/nav-menu.vue'

export default navMenu
