import pageSearch from './src/page-search.vue'

export default pageSearch
