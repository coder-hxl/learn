import pageContent from './src/page-content.vue'

export default pageContent
