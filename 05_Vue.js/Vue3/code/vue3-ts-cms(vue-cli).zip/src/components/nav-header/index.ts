import navHeader from './src/nav-header.vue'

export default navHeader
