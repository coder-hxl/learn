export interface IListState {
  usersList: any[]
  usersCount: number
  departmentList: any[]
  departmentCount: number
  menuList: any[]
  menuCount: number
  roleList: any[]
  roleCount: number

  categoryList: any[]
  categoryCount: number
  goodsList: any[]
  goodsCount: number
}
