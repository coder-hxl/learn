// 声明文件

declare const $filter: {
  formatTime(value: string): string
}
