<template>
  <div class="list">
    <h2>list</h2>
  </div>
</template>

<script setup lang="ts"></script>

<style scoped></style>
