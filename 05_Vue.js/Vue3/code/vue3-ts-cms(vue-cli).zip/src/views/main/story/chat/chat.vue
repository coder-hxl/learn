<template>
  <div class="chat">
    <h2>chat</h2>
  </div>
</template>

<script setup lang="ts"></script>

<style scoped></style>
