<template>
  <div class="dashboard">
    <h2>dashboard</h2>
  </div>
</template>

<script setup lang="ts"></script>

<style scoped></style>
