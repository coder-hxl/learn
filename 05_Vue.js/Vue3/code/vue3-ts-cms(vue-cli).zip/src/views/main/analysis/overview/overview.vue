<template>
  <div class="overview">
    <h2>overview</h2>
  </div>
</template>

<script setup lang="ts"></script>

<style scoped></style>
