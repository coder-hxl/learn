import FhTable from './src/table.vue'

export default FhTable
